Nested station-count coordinate-recording-error case: error6

Truth:
  T1 = clean baseline synthetic travel times
  T2 = clean baseline + -5% anomaly synthetic travel times
  clean travel times come from residualFirst.dat column 3

Controlled error:
  erroneous stations = 6/20
  fixed shift magnitude = 500 m
  each selected station uses the same wrong coordinate in T1 and T2
  first two error azimuths = 90 deg
  additional-station azimuth seed = 20260817

Observation system:
  full paths = 2092
  affected paths = 1176
  affected fraction = 56.214149%
  paths with both endpoints erroneous = 216
  no paths are deleted

MANDATORY: synthetic = 0

T1 audit: {'n_records': 2092, 'affected_records': 1176, 'both_endpoints_shifted_records': 216, 'affected_fraction_percent': 56.21414913957935, 'tt_reconstruction_rms_ms': 3.3486642387732933e-13, 'tt_reconstruction_maxabs_ms': 1.7763568394002505e-12, 'distance_ratio_min': 0.8845079660354928, 'distance_ratio_max': 1.1054722538826216}
T2 audit: {'n_records': 2092, 'affected_records': 1176, 'both_endpoints_shifted_records': 216, 'affected_fraction_percent': 56.21414913957935, 'tt_reconstruction_rms_ms': 3.510833468576701e-13, 'tt_reconstruction_maxabs_ms': 1.7763568394002505e-12, 'distance_ratio_min': 0.8845079660354928, 'distance_ratio_max': 1.1054722538826216}
Auto-copied: []
Warnings: []
