#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Plot nested station-count coordinate-recording-error tests.

Experiment root (default):
    /Users/zhaoqian/Desktop/stationerror/stationerror_count_500m

Cases:
    error2, error4, error6, error8

Default zero-error baseline:
    /Users/zhaoqian/Desktop/stationerror/stationerror2_difm/0m

Outputs
-------
1) Absolute recovery:
       row 1 = erroneous-station geometry
       row 2 = common-PDS
       row 3 = DSurfTomo-4D

2) Contamination relative to the zero-error 0m control:
       row 1 = erroneous-station geometry
       row 2 = common-PDS(errorN) - common-PDS(0m)
       row 3 = DSurfTomo-4D(errorN) - DSurfTomo-4D(0m)

3) Raw-node contamination trend:
       global RMS contamination vs erroneous-station count
       background RMS contamination vs erroneous-station count

Incomplete cases are skipped automatically.

Display style follows Figure 2 / azimuth-sector plotting conventions:
    Times New Roman
    original regular inversion grid
    edge-protected NaN-normalized Gaussian smoothing
    imshow bicubic interpolation
    seismic colormap + TwoSlopeNorm
    target box
    1200 dpi
Metrics are ALWAYS calculated from raw, unsmoothed inversion nodes.

Run:
    cd /Users/zhaoqian/Desktop/stationerror/stationerror_count_500m
    python3 plot_m05_station_count_error_dynamic.py

Optional:
    python3 plot_m05_station_count_error_dynamic.py \
        --depth 0.8 \
        --abs-vlim 5 \
        --contam-vlim 0 \
        --sigma 0.20 \
        --interpolation bicubic

Notes:
    --abs-vlim defaults to 5.0%, matching the -5% synthetic target amplitude.
    --contam-vlim 0 means automatic symmetric scaling.
"""

from __future__ import annotations

from argparse import ArgumentParser
from pathlib import Path
import csv
import math
import string

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
from matplotlib.ticker import FuncFormatter


# ============================================================================
# 0. Style
# ============================================================================

plt.rcParams.update({
    "font.family": "Times New Roman",
    "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "axes.unicode_minus": False,
    "font.weight": "normal",
    "axes.titleweight": "normal",
    "axes.labelweight": "normal",
    "axes.linewidth": 0.8,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})

# ============================================================
# Figure-2-style tunable parameters
# ============================================================
FIG_W_CM = 28.5
FIG_H_CM = 18.8
DPI = 1200

# Match the accepted station-drop / azimuth-sector scripts.
TEXT_FS = 15.0
NOTE_FS = 13.0
TITLE_FS = 16.0
PANEL_FS = 15.0
ROW_FS = 18.0
LEGEND_FS = 12.0
XTICK_FS = 13.0
YTICK_FS = 13.0
CBAR_FS = 15.0
CBAR_TICK_FS = 13.0

LINE_LW = 0.8
THIN_LW = 0.35
BOX_LW = 0.8
DPI = 1200

XTICK_PAD = 3.0
YTICK_PAD = 2.0
PANEL_LABEL_DX = -4
PANEL_LABEL_DY = 4

# Use the same Figure-2-style layout family as the other two scripts.
LEFT_MARGIN = 0.120
RIGHT_MARGIN = 0.885
BOTTOM_MARGIN = 0.090
TOP_MARGIN = 0.975
WSPACE = 0.130
HSPACE = 0.105
ROW_LABELPAD = 10.0

# Coordinate-error magnitude note shown inside the first-row panels.
# Change only this string for other experiments, e.g. "200 m".
SHIFT_LABEL = "500 m"
SHIFT_LABEL_FS = 13.0
SHIFT_LABEL_X = 0.04
SHIFT_LABEL_Y = 0.91

DEFAULT_SIGMA = 0.20
DEFAULT_INTERPOLATION = "bicubic"

STATION_MARKER = "^"
STATION_SIZE = 18
SPECIAL_STATION_SIZE = 18
STATION_FACECOLOR = "white"
STATION_EDGECOLOR = "black"
STATION_LINEWIDTH = 0.60
SPECIAL_STATION_LINEWIDTH = 0.60
RECORDED_SIZE = 34
ARROW_COLOR = "#EF3B2C"
ARROW_LW = 0.90
# Direction arrows are schematic: magnify the true 500 m coordinate shift
# for visibility while preserving its azimuth.
ERROR_ARROW_SCALE = 5.0
ERROR_ARROW_START_FRACTION = 0.18
ERROR_ARROW_HEAD_SCALE = 10

XTICKS = [121.40, 121.50, 121.60]
YTICKS = [25.00, 25.10, 25.20]

CASE_SPECS = [
    ("error2", "2 erroneous stations"),
    ("error4", "4 erroneous stations"),
    ("error6", "6 erroneous stations"),
    ("error8", "8 erroneous stations"),
]

# Fraction of the 2092 full paths affected by at least one erroneous station.
# N=0 is the true zero-error baseline from stationerror2_difm/0m.
AFFECTED_PATH_PERCENT = {
    0: 0.00,
    2: 18.02,
    4: 41.06,
    6: 56.21,
    8: 69.60,
}

TARGET_BOX = (
    121.460505, 121.511495,
    25.057500, 25.102500,
)


# ============================================================================
# 1. Generic helpers
# ============================================================================

def cm_to_inch(value: float) -> float:
    return value / 2.54


def degree_formatter(value: float, _position: int) -> str:
    return f"{value:.2f}°"


def lon_formatter(value: float, _position: int) -> str:
    return f"{value:.2f}°E"


def lat_formatter(value: float, _position: int) -> str:
    return f"{value:.2f}°N"


def require_file(path: Path, description: str) -> Path:
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(
            f"Cannot find {description}: {path}"
        )
    return path


def first_existing(paths: list[Path], description: str) -> Path:
    for path in paths:
        path = Path(path)
        if path.is_file():
            return path
    raise FileNotFoundError(
        f"Cannot find {description}. Tried:\n"
        + "\n".join(str(Path(p)) for p in paths)
    )


def optional_first_existing(paths: list[Path]) -> Path | None:
    for path in paths:
        path = Path(path)
        if path.is_file():
            return path
    return None


def final_model_in(directory: Path, description: str) -> Path:
    return first_existing(
        [
            directory / "DSurfTomo.inSyn.dat",
            directory / "DSurfTomo.inMeasure.dat",
        ],
        description,
    )


# ============================================================================
# 2. Model reading and percent calculations
# ============================================================================

def load_xyzv(path: Path) -> np.ndarray:
    path = require_file(path, "model file")
    arr = np.loadtxt(path, dtype=float)

    if arr.ndim == 1:
        arr = arr.reshape(1, -1)

    if arr.shape[1] < 4:
        raise ValueError(
            f"Fewer than four columns in {path}"
        )

    return arr[:, :4]


def model_key(
    lon: float,
    lat: float,
    depth: float,
) -> tuple:
    return (
        round(float(lon), 6),
        round(float(lat), 6),
        round(float(depth), 4),
    )


def array_to_dict(
    array: np.ndarray,
) -> dict[tuple, float]:
    out = {}

    for lon, lat, depth, value in array[:, :4]:
        key = model_key(
            lon,
            lat,
            depth,
        )

        if key in out:
            raise RuntimeError(
                f"Duplicate model node: {key}"
            )

        out[key] = float(value)

    return out


def build_model_difference_percent(
    reference_array: np.ndarray,
    current_array: np.ndarray,
) -> np.ndarray:
    """
    100 * (Vs_T2 - Vs_T1) / Vs_T1
    """
    reference = array_to_dict(
        reference_array
    )
    current = array_to_dict(
        current_array
    )

    keys = sorted(
        set(reference)
        & set(current)
    )

    if not keys:
        raise RuntimeError(
            "No common nodes between T1/T2 absolute models."
        )

    rows = []

    for key in keys:
        denominator = reference[key]

        if abs(denominator) < 1.0e-12:
            raise ZeroDivisionError(
                f"Zero reference velocity at {key}"
            )

        percent = (
            current[key] - denominator
        ) / denominator * 100.0

        rows.append([
            key[0],
            key[1],
            key[2],
            percent,
        ])

    return np.asarray(
        rows,
        dtype=float,
    )


def build_delta_percent(
    delta_array: np.ndarray,
    denominator_array: np.ndarray,
) -> np.ndarray:
    """
    100 * deltaVs_4D / Vs_reference
    """
    delta = array_to_dict(
        delta_array
    )
    denominator = array_to_dict(
        denominator_array
    )

    keys = sorted(
        set(delta)
        & set(denominator)
    )

    if not keys:
        raise RuntimeError(
            "No common nodes between 4D delta and denominator."
        )

    rows = []

    for key in keys:
        ref_value = denominator[key]

        if abs(ref_value) < 1.0e-12:
            raise ZeroDivisionError(
                f"Zero denominator at {key}"
            )

        percent = (
            delta[key]
            / ref_value
            * 100.0
        )

        rows.append([
            key[0],
            key[1],
            key[2],
            percent,
        ])

    return np.asarray(
        rows,
        dtype=float,
    )


def subtract_percent_models(
    current: np.ndarray,
    baseline: np.ndarray,
) -> np.ndarray:
    """
    current - baseline, both already in percent.
    Output unit: percentage points.
    """
    cur = array_to_dict(
        current
    )
    ref = array_to_dict(
        baseline
    )

    if set(cur) != set(ref):
        raise RuntimeError(
            "Model grids differ while computing contamination."
        )

    rows = []

    for key in sorted(ref):
        rows.append([
            key[0],
            key[1],
            key[2],
            cur[key] - ref[key],
        ])

    return np.asarray(
        rows,
        dtype=float,
    )


# ============================================================================
# 3. Result path discovery
# ============================================================================

def case_result_paths(
    case_dir: Path,
) -> dict[str, Path]:
    pds_root = (
        case_dir
        / "common-PDS"
    )

    pds_t1_dirs = [
        pds_root / "pdsT1",
        pds_root / "common-PDST1",
        pds_root / "commonPDS_T1",
        pds_root / "indT1",
        pds_root / "T1",
    ]

    pds_t2_dirs = [
        pds_root / "pdsT2",
        pds_root / "common-PDST2",
        pds_root / "commonPDS_T2",
        pds_root / "indT2",
        pds_root / "T2",
    ]

    pds_t1 = None

    for directory in pds_t1_dirs:
        if directory.is_dir():
            try:
                pds_t1 = final_model_in(
                    directory,
                    f"{case_dir.name} common-PDS T1",
                )
                break
            except FileNotFoundError:
                pass

    pds_t2 = None

    for directory in pds_t2_dirs:
        if directory.is_dir():
            try:
                pds_t2 = final_model_in(
                    directory,
                    f"{case_dir.name} common-PDS T2",
                )
                break
            except FileNotFoundError:
                pass

    fourd_dir = (
        case_dir / "4D"
    )

    fourd_delta = optional_first_existing([
        fourd_dir / "DSurfTomo.deltaVs.dat",
        fourd_dir / "DSurfTomo.deltaVS.dat",
        fourd_dir / "DSurfTomo.deltaVsError.dat",
    ])

    # Keep the robust denominator fallbacks used by the previous working script.
    fourd_denom = optional_first_existing([
        fourd_dir / "Vs_model.real",
        fourd_dir / "DSurfTomo.trueT1.dat",
        fourd_dir / "T1_reference_model.dat",
        fourd_dir / "DSurfTomo.inSyn.dat",
        fourd_dir / "DSurfTomo.inMeasure.dat",
    ])

    station_csv = (
        case_dir
        / "station_coordinate_errors.csv"
    )

    result = {
        "pds_t1": pds_t1,
        "pds_t2": pds_t2,
        "fourd_delta": fourd_delta,
        "fourd_denom": fourd_denom,
        "station_csv": (
            station_csv
            if station_csv.is_file()
            else None
        ),
    }

    return result


def load_case(
    case_dir: Path,
    require_station_csv: bool = True,
) -> dict:
    """
    Load one completed inversion case.

    Count-error cases require the new station-coordinate CSV because it is
    plotted in the first row. The external 0 m baseline is used only for model
    subtraction, so its older station CSV must not be parsed.
    """
    paths = case_result_paths(
        case_dir
    )

    required_keys = [
        "pds_t1",
        "pds_t2",
        "fourd_delta",
        "fourd_denom",
    ]

    if require_station_csv:
        required_keys.append(
            "station_csv"
        )

    missing = [
        key
        for key in required_keys
        if paths.get(key) is None
    ]

    if missing:
        raise FileNotFoundError(
            f"{case_dir.name}: missing "
            + ", ".join(missing)
        )

    pds_t1 = load_xyzv(
        paths["pds_t1"]
    )

    pds_t2 = load_xyzv(
        paths["pds_t2"]
    )

    fourd_delta = load_xyzv(
        paths["fourd_delta"]
    )

    fourd_denom = load_xyzv(
        paths["fourd_denom"]
    )

    station_errors = []

    if require_station_csv:
        station_errors = read_station_error_csv(
            paths["station_csv"]
        )

    return {
        "name": case_dir.name,
        "case_dir": case_dir,
        "paths": paths,
        "common-PDS":
            build_model_difference_percent(
                pds_t1,
                pds_t2,
            ),
        "DSurfTomo-4D":
            build_delta_percent(
                fourd_delta,
                fourd_denom,
            ),
        "station_errors":
            station_errors,
    }


def discover_available_cases(
    root: Path,
) -> tuple[list[dict], list[tuple[str, list[str]]]]:
    available = []
    skipped = []

    for case_name, title in CASE_SPECS:
        case_dir = (
            root / case_name
        )

        if not case_dir.is_dir():
            skipped.append((
                case_name,
                ["case directory"],
            ))
            continue

        paths = case_result_paths(
            case_dir
        )

        missing = [
            key
            for key, value
            in paths.items()
            if value is None
        ]

        if missing:
            skipped.append((
                case_name,
                missing,
            ))
            continue

        case = load_case(
            case_dir,
            require_station_csv=True,
        )
        case["title"] = title
        available.append(
            case
        )

    return (
        available,
        skipped,
    )


# ============================================================================
# 4. Station parsing
# ============================================================================

def parse_surfdata(
    path: Path,
) -> tuple[np.ndarray, int]:
    path = require_file(
        path,
        "surfdata",
    )

    stations = set()
    path_count = 0

    with path.open(
        "r",
        encoding="utf-8",
        errors="ignore",
    ) as file_obj:
        for raw in file_obj:
            parts = raw.split()

            if not parts:
                continue

            if (
                parts[0].lower()
                == "c"
            ):
                continue

            if parts[0] == "#":
                if len(parts) >= 3:
                    stations.add((
                        round(
                            float(parts[1]),
                            6,
                        ),
                        round(
                            float(parts[2]),
                            6,
                        ),
                    ))
                continue

            if len(parts) >= 3:
                stations.add((
                    round(
                        float(parts[0]),
                        6,
                    ),
                    round(
                        float(parts[1]),
                        6,
                    ),
                ))

                path_count += 1

    if not stations:
        raise RuntimeError(
            f"No stations read from {path}"
        )

    return (
        np.asarray(
            sorted(stations),
            dtype=float,
        ),
        path_count,
    )


def read_station_error_csv(
    path: Path,
) -> list[dict]:
    rows = []

    with path.open(
        "r",
        encoding="utf-8-sig",
        newline="",
    ) as file_obj:
        reader = csv.DictReader(
            file_obj
        )

        required = {
            "selection_rank",
            "role",
            "true_lat",
            "true_lon",
            "recorded_lat",
            "recorded_lon",
            "requested_shift_m",
            "error_azimuth_deg",
            "inside_target",
            "path_degree",
        }

        fields = set(
            reader.fieldnames or []
        )

        missing_fields = (
            required - fields
        )

        if missing_fields:
            raise RuntimeError(
                f"{path} uses an incompatible station-error CSV schema. "
                f"Missing columns: {sorted(missing_fields)}"
            )

        for row in reader:
            rows.append({
                "rank":
                    int(row["selection_rank"]),
                "role":
                    row["role"],
                "true_lat":
                    float(row["true_lat"]),
                "true_lon":
                    float(row["true_lon"]),
                "recorded_lat":
                    float(row["recorded_lat"]),
                "recorded_lon":
                    float(row["recorded_lon"]),
                "shift_m":
                    float(row["requested_shift_m"]),
                "azimuth_deg":
                    float(row["error_azimuth_deg"]),
                "inside_target":
                    int(row["inside_target"]),
                "path_degree":
                    int(row["path_degree"]),
            })

    if not rows:
        raise RuntimeError(
            f"No station-coordinate-error rows in {path}"
        )

    return rows


# ============================================================================
# 5. Display grid and smoothing
# ============================================================================

def build_regular_grid(
    array: np.ndarray,
    target_depth: float,
) -> tuple[
    np.ndarray,
    np.ndarray,
    np.ndarray,
    float,
]:
    depths = np.sort(
        np.unique(
            np.round(
                array[:, 2],
                5,
            )
        )
    )

    actual_depth = float(
        depths[
            np.argmin(
                np.abs(
                    depths
                    - target_depth
                )
            )
        ]
    )

    selected = array[
        np.isclose(
            array[:, 2],
            actual_depth,
            atol=1.0e-5,
        )
    ]

    lons = np.sort(
        np.unique(
            np.round(
                selected[:, 0],
                6,
            )
        )
    )

    lats = np.sort(
        np.unique(
            np.round(
                selected[:, 1],
                6,
            )
        )
    )

    lon_index = {
        value: i
        for i, value
        in enumerate(lons)
    }

    lat_index = {
        value: i
        for i, value
        in enumerate(lats)
    }

    grid = np.full(
        (
            len(lats),
            len(lons),
        ),
        np.nan,
    )

    for (
        lon,
        lat,
        _depth,
        value,
    ) in selected:
        grid[
            lat_index[
                round(
                    float(lat),
                    6,
                )
            ],
            lon_index[
                round(
                    float(lon),
                    6,
                )
            ],
        ] = value

    return (
        lons,
        lats,
        grid,
        actual_depth,
    )


def depth_points(
    array: np.ndarray,
    target_depth: float,
) -> tuple[
    np.ndarray,
    np.ndarray,
    np.ndarray,
    float,
]:
    depths = np.sort(
        np.unique(
            np.round(
                array[:, 2],
                5,
            )
        )
    )

    actual_depth = float(
        depths[
            np.argmin(
                np.abs(
                    depths
                    - target_depth
                )
            )
        ]
    )

    selected = array[
        np.isclose(
            array[:, 2],
            actual_depth,
            atol=1.0e-5,
        )
    ]

    return (
        selected[:, 0],
        selected[:, 1],
        selected[:, 3],
        actual_depth,
    )


def gaussian_kernel_1d(
    sigma: float,
    truncate: float = 3.0,
) -> np.ndarray:
    if sigma <= 0:
        return np.asarray(
            [1.0],
            dtype=float,
        )

    radius = max(
        1,
        int(
            truncate * sigma
            + 0.5
        ),
    )

    coordinate = np.arange(
        -radius,
        radius + 1,
        dtype=float,
    )

    kernel = np.exp(
        -0.5
        * (
            coordinate / sigma
        ) ** 2
    )

    kernel /= np.sum(
        kernel
    )

    return kernel


def convolve_axis_edge(
    array: np.ndarray,
    kernel: np.ndarray,
    axis: int,
) -> np.ndarray:
    if len(kernel) == 1:
        return array.copy()

    radius = (
        len(kernel) // 2
    )

    pad_width = [
        (0, 0)
        for _ in range(
            array.ndim
        )
    ]

    pad_width[axis] = (
        radius,
        radius,
    )

    padded = np.pad(
        array,
        pad_width,
        mode="edge",
    )

    return np.apply_along_axis(
        lambda vector:
            np.convolve(
                vector,
                kernel,
                mode="valid",
            ),
        axis,
        padded,
    )


def gaussian_filter_2d(
    grid: np.ndarray,
    sigma: float,
) -> np.ndarray:
    if sigma <= 0:
        return grid.copy()

    valid = np.isfinite(
        grid
    )

    if not np.any(valid):
        return grid.copy()

    values = np.where(
        valid,
        grid,
        0.0,
    )

    weights = (
        valid.astype(float)
    )

    kernel = (
        gaussian_kernel_1d(
            sigma
        )
    )

    for axis in (0, 1):
        values = (
            convolve_axis_edge(
                values,
                kernel,
                axis,
            )
        )

        weights = (
            convolve_axis_edge(
                weights,
                kernel,
                axis,
            )
        )

    return np.divide(
        values,
        weights,
        out=np.full_like(
            values,
            np.nan,
        ),
        where=weights > 1.0e-12,
    )


def image_extent(
    longitudes: np.ndarray,
    latitudes: np.ndarray,
) -> tuple[
    float,
    float,
    float,
    float,
]:
    dx = (
        float(
            np.median(
                np.diff(
                    longitudes
                )
            )
        )
        if len(longitudes) > 1
        else 0.0
    )

    dy = (
        float(
            np.median(
                np.abs(
                    np.diff(
                        latitudes
                    )
                )
            )
        )
        if len(latitudes) > 1
        else 0.0
    )

    return (
        float(
            longitudes[0]
            - 0.5 * dx
        ),
        float(
            longitudes[-1]
            + 0.5 * dx
        ),
        float(
            latitudes[0]
            - 0.5 * dy
        ),
        float(
            latitudes[-1]
            + 0.5 * dy
        ),
    )


# ============================================================================
# 6. Axis / station-geometry plotting
# ============================================================================

def format_geo_axis(
    ax,
    mean_latitude: float,
    row: int,
    column: int,
    nrows: int,
    ncols: int,
) -> None:
    # Figure 2 convention: fixed geographic ticks with °E / °N labels;
    # only the left column shows latitude labels and only the bottom row
    # shows longitude labels. The visible map limits are set from the
    # actual model-grid min/max in make_three_row_figure().
    ax.set_xticks(XTICKS)
    ax.set_yticks(YTICKS)
    ax.xaxis.set_major_formatter(FuncFormatter(lon_formatter))
    ax.yaxis.set_major_formatter(FuncFormatter(lat_formatter))
    ax.grid(False)

    ax.tick_params(
        axis="x",
        which="both",
        direction="in",
        top=True,
        bottom=True,
        length=4.0,
        width=LINE_LW,
        labelsize=XTICK_FS,
        pad=XTICK_PAD,
    )
    ax.tick_params(
        axis="y",
        which="both",
        direction="in",
        left=True,
        right=True,
        length=4.0,
        width=LINE_LW,
        labelsize=YTICK_FS,
        pad=YTICK_PAD,
    )

    for spine in ax.spines.values():
        spine.set_linewidth(LINE_LW)

    if row < nrows - 1:
        ax.tick_params(labelbottom=False)

    if column > 0:
        ax.tick_params(labelleft=False)

    ax.set_aspect(
        1.0 / np.cos(np.deg2rad(mean_latitude)),
        adjustable="box",
    )


def add_true_box(ax) -> None:
    (
        lon_min,
        lon_max,
        lat_min,
        lat_max,
    ) = TARGET_BOX

    ax.add_patch(
        Rectangle(
            (
                lon_min,
                lat_min,
            ),
            lon_max - lon_min,
            lat_max - lat_min,
            fill=False,
            edgecolor="black",
            linewidth=0.8,
            linestyle="--",
            zorder=30,
        )
    )


def add_panel_label(
    ax,
    text: str,
) -> None:
    # Match the outside top-left panel labels used in the other scripts.
    ax.annotate(
        text,
        xy=(0, 1),
        xycoords="axes fraction",
        xytext=(PANEL_LABEL_DX, PANEL_LABEL_DY),
        textcoords="offset points",
        ha="left",
        va="bottom",
        fontsize=PANEL_FS,
        annotation_clip=False,
        zorder=50,
    )


def add_station_distribution(
    ax,
    all_stations: np.ndarray,
) -> None:
    """Draw the full station set using the same styling as the other scripts."""
    if len(all_stations) == 0:
        return
    all_stations = np.asarray(all_stations, dtype=float)
    ax.scatter(
        all_stations[:, 1],
        all_stations[:, 0],
        marker=STATION_MARKER,
        s=STATION_SIZE,
        facecolors=STATION_FACECOLOR,
        edgecolors=STATION_EDGECOLOR,
        linewidths=STATION_LINEWIDTH,
        zorder=20,
    )


def add_erroneous_station_overlay(
    ax,
    errors: list[dict],
) -> None:
    """Overlay erroneous stations as red hollow triangles."""
    if not errors:
        return
    lons = [float(row["true_lon"]) for row in errors]
    lats = [float(row["true_lat"]) for row in errors]
    ax.scatter(
        lons,
        lats,
        marker=STATION_MARKER,
        s=SPECIAL_STATION_SIZE,
        facecolors=STATION_FACECOLOR,
        edgecolors=ARROW_COLOR,
        linewidths=SPECIAL_STATION_LINEWIDTH,
        zorder=29,
    )


def add_station_error_map(
    ax,
    all_stations: np.ndarray,
    errors: list[dict],
) -> None:
    """
    Clean geometry panel:
    - normal stations = black hollow triangles
    - erroneous TRUE stations = red hollow triangles
    - no arrows, recorded-coordinate markers, or in-panel text
    """
    add_station_distribution(
        ax,
        all_stations,
    )

    for row in errors:
        true_lon = float(row["true_lon"])
        true_lat = float(row["true_lat"])
        dlon = float(row["recorded_lon"]) - true_lon
        dlat = float(row["recorded_lat"]) - true_lat

        # Mark the actual erroneous station location itself in red.
        ax.scatter(
            [true_lon],
            [true_lat],
            marker=STATION_MARKER,
            s=SPECIAL_STATION_SIZE,
            facecolors=STATION_FACECOLOR,
            edgecolors=ARROW_COLOR,
            linewidths=SPECIAL_STATION_LINEWIDTH,
            zorder=29,
        )

    add_true_box(ax)


# ============================================================================
# 7. Metrics
# ============================================================================

def calculate_absolute_metrics(
    result: np.ndarray,
    target_depth: float,
) -> dict:
    lon, lat, values, actual_depth = depth_points(
        result,
        target_depth,
    )

    (
        lon_min,
        lon_max,
        lat_min,
        lat_max,
    ) = TARGET_BOX

    target = (
        (lon >= lon_min)
        & (lon <= lon_max)
        & (lat >= lat_min)
        & (lat <= lat_max)
    )

    background = ~target

    return {
        "depth_km":
            actual_depth,
        "target_mean_percent":
            float(
                np.mean(
                    values[target]
                )
            ),
        "background_rms_percent":
            float(
                np.sqrt(
                    np.mean(
                        values[
                            background
                        ] ** 2
                    )
                )
            ),
        "background_max_abs_percent":
            float(
                np.max(
                    np.abs(
                        values[
                            background
                        ]
                    )
                )
            ),
    }


def calculate_contamination_metrics(
    contamination: np.ndarray,
    target_depth: float,
) -> dict:
    lon, lat, values, actual_depth = depth_points(
        contamination,
        target_depth,
    )

    (
        lon_min,
        lon_max,
        lat_min,
        lat_max,
    ) = TARGET_BOX

    target = (
        (lon >= lon_min)
        & (lon <= lon_max)
        & (lat >= lat_min)
        & (lat <= lat_max)
    )

    background = ~target

    return {
        "depth_km":
            actual_depth,
        "target_mean_change_pp":
            float(
                np.mean(
                    values[target]
                )
            ),
        "target_rms_contamination_pp":
            float(
                np.sqrt(
                    np.mean(
                        values[target] ** 2
                    )
                )
            ),
        "background_rms_contamination_pp":
            float(
                np.sqrt(
                    np.mean(
                        values[
                            background
                        ] ** 2
                    )
                )
            ),
        "background_max_abs_contamination_pp":
            float(
                np.max(
                    np.abs(
                        values[
                            background
                        ]
                    )
                )
            ),
        "global_rms_contamination_pp":
            float(
                np.sqrt(
                    np.mean(
                        values ** 2
                    )
                )
            ),
        "global_max_abs_contamination_pp":
            float(
                np.max(
                    np.abs(
                        values
                    )
                )
            ),
    }


def choose_auto_contam_vlim(
    contamination_cases: list[dict],
    depth: float,
) -> float:
    maxabs = 0.0

    for case in contamination_cases:
        for method in (
            "common-PDS",
            "DSurfTomo-4D",
        ):
            _, _, values, _ = depth_points(
                case[method],
                depth,
            )

            if values.size:
                maxabs = max(
                    maxabs,
                    float(
                        np.nanmax(
                            np.abs(values)
                        )
                    ),
                )

    if (
        not np.isfinite(maxabs)
        or maxabs <= 0
    ):
        return 0.10

    candidates = [
        0.05,
        0.10,
        0.15,
        0.20,
        0.25,
        0.30,
        0.40,
        0.50,
        0.75,
        1.00,
        1.50,
        2.00,
        3.00,
        5.00,
        7.50,
    ]

    target = (
        maxabs * 1.03
    )

    for value in candidates:
        if value >= target:
            return value

    return (
        math.ceil(
            target * 2.0
        )
        / 2.0
    )


# ============================================================================
# 8. Shared figure maker
# ============================================================================

def make_three_row_figure(
    *,
    cases: list[dict],
    all_stations: np.ndarray,
    depth: float,
    vlim: float,
    sigma: float,
    interpolation: str,
    kind: str,
    output_dir: Path,
) -> tuple[
    list[dict],
    list[Path],
]:
    if kind not in {
        "absolute",
        "contamination",
    }:
        raise ValueError(
            kind
        )

    ref_lon, ref_lat, _, selected_depth = (
        build_regular_grid(
            cases[0]["common-PDS"],
            depth,
        )
    )

    # Figure 2 geographic frame: use the ACTUAL model-grid min/max as
    # the visible frame, not the half-grid-cell-expanded imshow extent.
    xlim = (
        float(np.min(ref_lon)),
        float(np.max(ref_lon)),
    )
    ylim = (
        float(np.min(ref_lat)),
        float(np.max(ref_lat)),
    )

    mean_latitude = float(
        np.mean(ref_lat)
    )

    ncols = len(cases)
    nrows = 3

    fig_width_cm = FIG_W_CM

    fig_height_cm = FIG_H_CM

    fig, axes = plt.subplots(
        nrows,
        ncols,
        figsize=(
            cm_to_inch(
                fig_width_cm
            ),
            cm_to_inch(
                fig_height_cm
            ),
        ),
        sharex=True,
        sharey=True,
        squeeze=False,
    )

    left = LEFT_MARGIN
    right = RIGHT_MARGIN

    fig.subplots_adjust(
        left=left,
        right=right,
        bottom=BOTTOM_MARGIN,
        top=TOP_MARGIN,
        wspace=WSPACE,
        hspace=HSPACE,
    )

    # Column titles are intentionally removed to match the requested clean style.

    norm = TwoSlopeNorm(
        vmin=-vlim,
        vcenter=0.0,
        vmax=vlim,
    )

    image = None
    metrics_rows = []
    for column, case in enumerate(cases):
        # row 1: station geometry
        ax = axes[0, column]

        add_station_error_map(
            ax,
            all_stations,
            case["station_errors"],
        )

        ax.set_xlim(*xlim)
        ax.set_ylim(*ylim)

        format_geo_axis(
            ax,
            mean_latitude,
            0,
            column,
            nrows,
            ncols,
        )

        # Error magnitude: keep this as the only in-panel annotation in row 1.
        ax.text(
            SHIFT_LABEL_X,
            SHIFT_LABEL_Y,
            SHIFT_LABEL,
            transform=ax.transAxes,
            ha="left",
            va="top",
            fontsize=SHIFT_LABEL_FS,
            fontfamily="Times New Roman",
            color="black",
            zorder=60,
        )

        for row, method in (
            (
                1,
                "common-PDS",
            ),
            (
                2,
                "DSurfTomo-4D",
            ),
        ):
            ax = axes[
                row,
                column,
            ]

            result = (
                case[method]
            )

            (
                lon,
                lat,
                raw_grid,
                actual_depth,
            ) = build_regular_grid(
                result,
                depth,
            )

            shown_grid = (
                gaussian_filter_2d(
                    raw_grid,
                    sigma=float(
                        sigma
                    ),
                )
            )

            image = ax.imshow(
                shown_grid,
                extent=image_extent(
                    lon,
                    lat,
                ),
                origin="lower",
                cmap="seismic",
                norm=norm,
                interpolation=str(
                    interpolation
                ),
                rasterized=True,
                aspect="auto",
            )

            add_station_distribution(
                ax,
                all_stations,
            )
            add_erroneous_station_overlay(
                ax,
                case["station_errors"],
            )
            add_true_box(
                ax
            )

            ax.set_xlim(*xlim)
            ax.set_ylim(*ylim)

            format_geo_axis(
                ax,
                mean_latitude,
                row,
                column,
                nrows,
                ncols,
            )

            if kind == "absolute":
                metrics = (
                    calculate_absolute_metrics(
                        result,
                        depth,
                    )
                )

                metrics_rows.append({
                    "figure_type":
                        "absolute_recovery",
                    "case":
                        case["name"],
                    "method":
                        method,
                    **metrics,
                })

            else:
                metrics = (
                    calculate_contamination_metrics(
                        result,
                        depth,
                    )
                )

                metrics_rows.append({
                    "figure_type":
                        "relative_to_0m_contamination",
                    "case":
                        case["name"],
                    "method":
                        method,
                    **metrics,
                })


    # Panel labels in conventional row-major order:
    # (a)-(d) top row, (e)-(h) middle row, (i)-(l) bottom row.
    panel_labels = [
        ["(a)", "(b)", "(c)", "(d)"],
        ["(e)", "(f)", "(g)", "(h)"],
        ["(i)", "(j)", "(k)", "(l)"],
    ]
    for r in range(nrows):
        for c in range(ncols):
            add_panel_label(axes[r, c], panel_labels[r][c])

    if kind == "absolute":
        row_labels = [
            "Coordinate errors",
            "common-path PDS",
            "DSurfTomo-4D",
        ]

        cbar_label = (
            r"$\Delta V_s/V_s$ (%)"
        )

        file_tag = (
            "absolute_recovery"
        )

    else:
        row_labels = [
            "Coordinate errors",
            r"common-path PDS $-$ 0 m",
            r"DSurfTomo-4D $-$ 0 m",
        ]

        cbar_label = (
            r"Contamination in "
            r"$\Delta V_s/V_s$ "
            r"(percentage points)"
        )

        file_tag = (
            "contamination_vs_0m"
        )

    for row, label_text in enumerate(row_labels):
        axes[row, 0].set_ylabel(
            label_text,
            fontsize=ROW_FS,
            labelpad=ROW_LABELPAD,
        )

    # Shared colorbar spans the two inversion rows.
    pos_top = axes[
        1,
        -1,
    ].get_position()

    pos_bottom = axes[
        2,
        -1,
    ].get_position()

    full_y0 = pos_bottom.y0
    full_y1 = pos_top.y1
    full_height = (
        full_y1 - full_y0
    )

    cbar_height = (
        full_height * 0.88
    )

    cbar_y0 = (
        full_y0
        + (
            full_height
            - cbar_height
        ) / 2.0
    )

    cbar_ax = fig.add_axes([
        right + 0.018,
        cbar_y0,
        0.014,
        cbar_height,
    ])

    if kind == "absolute":
        cbar_ticks = np.linspace(
            -vlim,
            vlim,
            5,
        )
    else:
        cbar_ticks = np.linspace(
            -vlim,
            vlim,
            7,
        )

    cbar = fig.colorbar(
        image,
        cax=cbar_ax,
        extend="neither",
        ticks=cbar_ticks,
    )

    cbar.set_label(
        cbar_label,
        fontsize=CBAR_FS,
        rotation=90,
        labelpad=4,
    )

    cbar.ax.tick_params(
        direction="in",
        length=3,
        width=LINE_LW,
        labelsize=CBAR_TICK_FS,
    )

    cbar.outline.set_linewidth(
        LINE_LW
    )

    case_tag = "_".join(
        case["name"]
        for case in cases
    )

    depth_tag = (
        f"{selected_depth:.1f}"
        .replace(
            ".",
            "p",
        )
    )

    out_png = (
        output_dir
        / (
            f"m05_station_count_error_fig2geoframe_"
            f"{file_tag}_"
            f"{case_tag}_"
            f"{depth_tag}km.png"
        )
    )

    out_pdf = (
        output_dir
        / (
            f"m05_station_count_error_fig2geoframe_"
            f"{file_tag}_"
            f"{case_tag}_"
            f"{depth_tag}km.pdf"
        )
    )

    out_svg = (
        output_dir
        / (
            f"m05_station_count_error_fig2geoframe_"
            f"{file_tag}_"
            f"{case_tag}_"
            f"{depth_tag}km.svg"
        )
    )

    fig.savefig(
        out_png,
        dpi=DPI,
        bbox_inches="tight",
        pad_inches=0.03,
    )

    fig.savefig(
        out_pdf,
        bbox_inches="tight",
        pad_inches=0.03,
    )

    fig.savefig(
        out_svg,
        bbox_inches="tight",
        pad_inches=0.03,
    )

    plt.close(
        fig
    )

    return (
        metrics_rows,
        [
            out_png,
            out_pdf,
            out_svg,
        ],
    )


# ============================================================================
# 9. Trend figure
# ============================================================================

def make_trend_figures(
    contamination_metrics: list[dict],
    output_dir: Path,
) -> list[Path]:
    """
    Plot contamination trends including the true zero-error control.

    The baseline point is exactly:
        N = 0 erroneous stations
        contamination = 0 percentage points

    because each method is differenced against its own 0 m model.

    Bottom x-axis:
        Number of erroneous stations

    Top x-axis:
        Fraction of the 2092 paths affected by erroneous coordinates (%)
    """
    methods = [
        "common-PDS",
        "DSurfTomo-4D",
    ]

    outputs = []

    for metric_key, ylabel, tag in (
        (
            "global_rms_contamination_pp",
            "Global RMS contamination (percentage points)",
            "global_rms",
        ),
        (
            "background_rms_contamination_pp",
            "Background RMS contamination (percentage points)",
            "background_rms",
        ),
    ):
        fig, ax = plt.subplots(
            figsize=(
                cm_to_inch(9.2),
                cm_to_inch(6.8),
            )
        )

        for method in methods:
            rows = [
                row
                for row
                in contamination_metrics
                if row["method"] == method
            ]

            rows = sorted(
                rows,
                key=lambda row:
                    int(
                        row["case"]
                        .replace(
                            "error",
                            "",
                        )
                    ),
            )

            # Existing completed count-error cases.
            x_existing = np.asarray([
                int(
                    row["case"]
                    .replace(
                        "error",
                        "",
                    )
                )
                for row in rows
            ], dtype=int)

            y_existing = np.asarray([
                row[metric_key]
                for row in rows
            ], dtype=float)

            # Add the exact zero-error reference point.
            x = np.concatenate(
                (
                    np.asarray([0], dtype=int),
                    x_existing,
                )
            )

            y = np.concatenate(
                (
                    np.asarray([0.0], dtype=float),
                    y_existing,
                )
            )

            ax.plot(
                x,
                y,
                marker="o",
                linewidth=1.0,
                markersize=4.0,
                label=method,
            )

        ax.set_xlabel(
            "Number of erroneous stations",
            fontsize=TEXT_FS,
        )

        ax.set_ylabel(
            ylabel,
            fontsize=TEXT_FS,
        )

        # Always show the full designed count sequence, even if error8
        # has not yet finished.
        count_ticks = [
            0,
            2,
            4,
            6,
            8,
        ]

        ax.set_xticks(
            count_ticks
        )

        ax.set_xlim(
            -0.25,
            8.25,
        )

        ax.set_ylim(
            bottom=0.0
        )

        ax.tick_params(
            direction="in",
            top=False,
            right=True,
            length=4,
            width=0.8,
            labelsize=NOTE_FS,
        )

        for spine in ax.spines.values():
            spine.set_linewidth(
                0.8
            )

        # Secondary top x-axis: affected-path fraction.
        ax_top = ax.twiny()

        ax_top.set_xlim(
            ax.get_xlim()
        )

        ax_top.set_xticks(
            count_ticks
        )

        ax_top.set_xticklabels(
            [
                f"{AFFECTED_PATH_PERCENT[n]:.1f}"
                for n in count_ticks
            ],
            fontsize=NOTE_FS,
        )

        ax_top.set_xlabel(
            "Affected paths (%)",
            fontsize=TEXT_FS,
            labelpad=3,
        )

        ax_top.tick_params(
            axis="x",
            direction="in",
            top=True,
            bottom=False,
            length=4,
            width=0.8,
            labelsize=NOTE_FS,
        )

        for spine in ax_top.spines.values():
            spine.set_linewidth(
                0.8
            )

        ax.legend(
            frameon=False,
            fontsize=LEGEND_FS,
            loc="upper left",
        )

        fig.tight_layout()

        out_png = (
            output_dir
            / f"m05_station_count_error_trend_{tag}_with0.png"
        )

        out_pdf = (
            output_dir
            / f"m05_station_count_error_trend_{tag}_with0.pdf"
        )

        out_svg = (
            output_dir
            / f"m05_station_count_error_trend_{tag}_with0.svg"
        )

        fig.savefig(
            out_png,
            dpi=DPI,
            bbox_inches="tight",
            pad_inches=0.03,
        )

        fig.savefig(
            out_pdf,
            bbox_inches="tight",
            pad_inches=0.03,
        )

        fig.savefig(
            out_svg,
            bbox_inches="tight",
            pad_inches=0.03,
        )

        plt.close(
            fig
        )

        outputs.extend([
            out_png,
            out_pdf,
            out_svg,
        ])

    return outputs


# ============================================================================
# 10. Main
# ============================================================================

def main() -> None:
    parser = ArgumentParser(
        description=(
            "Dynamic station-count-error plotting "
            "for error2/error4/error6/error8."
        )
    )

    parser.add_argument(
        "--root",
        type=Path,
        default=Path.cwd(),
        help=(
            "stationerror_count_500m root; "
            "default=current directory"
        ),
    )

    parser.add_argument(
        "--baseline",
        type=Path,
        default=None,
        help=(
            "Zero-error 0m case directory. "
            "Default: ../stationerror2_difm/0m"
        ),
    )

    parser.add_argument(
        "--depth",
        type=float,
        default=0.8,
    )

    parser.add_argument(
        "--abs-vlim",
        type=float,
        default=5.0,
    )

    parser.add_argument(
        "--contam-vlim",
        type=float,
        default=0.0,
        help=(
            "Contamination color limit. "
            "0 = automatic."
        ),
    )

    parser.add_argument(
        "--sigma",
        type=float,
        default=DEFAULT_SIGMA,
    )

    parser.add_argument(
        "--interpolation",
        choices=(
            "nearest",
            "bilinear",
            "bicubic",
        ),
        default=DEFAULT_INTERPOLATION,
    )

    args = parser.parse_args()

    root = (
        args.root
        .expanduser()
        .resolve()
    )

    if not root.is_dir():
        raise FileNotFoundError(
            f"Root directory does not exist: {root}"
        )

    baseline_dir = (
        args.baseline
        .expanduser()
        .resolve()
        if args.baseline
        is not None
        else (
            root.parent
            / "stationerror2_difm"
            / "0m"
        ).resolve()
    )

    if not baseline_dir.is_dir():
        raise FileNotFoundError(
            "Cannot find zero-error baseline directory: "
            f"{baseline_dir}\n"
            "Use --baseline /path/to/0m if needed."
        )

    # Full clean station source.
    station_source = first_existing(
        [
            root.parent / "surfdata_T2.dat",
            root / "surfdata_T2.dat",
        ],
        "full clean T2 surfdata",
    )

    all_stations, full_paths = (
        parse_surfdata(
            station_source
        )
    )

    cases, skipped = (
        discover_available_cases(
            root
        )
    )

    print(
        "=" * 88
    )

    print(
        "AVAILABLE COUNT-ERROR CASES"
    )

    print(
        "=" * 88
    )

    for case in cases:
        print(
            f"  {case['name']:6s}  "
            f"({case['title']})"
        )

    if skipped:
        print(
            "\nSkipped incomplete/unavailable cases:"
        )

        for (
            case_name,
            missing,
        ) in skipped:
            print(
                f"  {case_name:6s}: "
                + ", ".join(
                    missing
                )
            )

    if not cases:
        raise RuntimeError(
            "No completed station-count-error cases found."
        )

    # Load the true zero-error baseline from the previous 0m experiment.
    baseline = load_case(
        baseline_dir,
        require_station_csv=False,
    )

    print(
        f"\nZero-error baseline: {baseline_dir}"
    )

    print(
        f"Full clean station source: {station_source}"
    )

    print(
        f"Stations: {len(all_stations)}; "
        f"paths: {full_paths}"
    )

    # Build contamination against the same zero-error result for each method.
    contamination_cases = []

    for case in cases:
        contamination_cases.append({
            "name":
                case["name"],
            "title":
                case["title"],
            "case_dir":
                case["case_dir"],
            "paths":
                case["paths"],
            "station_errors":
                case["station_errors"],
            "common-PDS":
                subtract_percent_models(
                    case["common-PDS"],
                    baseline["common-PDS"],
                ),
            "DSurfTomo-4D":
                subtract_percent_models(
                    case["DSurfTomo-4D"],
                    baseline["DSurfTomo-4D"],
                ),
        })

    contam_vlim = (
        float(
            args.contam_vlim
        )
        if args.contam_vlim > 0
        else choose_auto_contam_vlim(
            contamination_cases,
            args.depth,
        )
    )

    print(
        f"Absolute color limit: "
        f"±{args.abs_vlim:g}%"
    )

    print(
        "Contamination color limit: "
        f"±{contam_vlim:g} percentage points"
    )

    output_dir = (
        root
        / "station_count_error_figure_output"
    )

    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    absolute_metrics, absolute_outputs = (
        make_three_row_figure(
            cases=cases,
            all_stations=all_stations,
            depth=args.depth,
            vlim=float(
                args.abs_vlim
            ),
            sigma=float(
                args.sigma
            ),
            interpolation=str(
                args.interpolation
            ),
            kind="absolute",
            output_dir=output_dir,
        )
    )

    contamination_metrics, contamination_outputs = (
        make_three_row_figure(
            cases=contamination_cases,
            all_stations=all_stations,
            depth=args.depth,
            vlim=contam_vlim,
            sigma=float(
                args.sigma
            ),
            interpolation=str(
                args.interpolation
            ),
            kind="contamination",
            output_dir=output_dir,
        )
    )

    trend_outputs = (
        make_trend_figures(
            contamination_metrics,
            output_dir,
        )
    )

    case_tag = "_".join(
        case["name"]
        for case in cases
    )

    absolute_csv = (
        output_dir
        / f"m05_station_count_error_absolute_metrics_{case_tag}.csv"
    )

    with absolute_csv.open(
        "w",
        newline="",
        encoding="utf-8-sig",
    ) as file_obj:
        writer = csv.DictWriter(
            file_obj,
            fieldnames=list(
                absolute_metrics[0].keys()
            ),
        )

        writer.writeheader()
        writer.writerows(
            absolute_metrics
        )

    contamination_csv = (
        output_dir
        / f"m05_station_count_error_contamination_metrics_{case_tag}.csv"
    )

    with contamination_csv.open(
        "w",
        newline="",
        encoding="utf-8-sig",
    ) as file_obj:
        writer = csv.DictWriter(
            file_obj,
            fieldnames=list(
                contamination_metrics[0].keys()
            ),
        )

        writer.writeheader()
        writer.writerows(
            contamination_metrics
        )

    print(
        "\n"
        + "=" * 88
    )

    print(
        "ABSOLUTE RECOVERY — raw-node metrics"
    )

    print(
        "=" * 88
    )

    for row in absolute_metrics:
        print(
            f"  {row['case']:6s} "
            f"{row['method']:14s} "
            f"target="
            f"{row['target_mean_percent']:8.3f}%  "
            f"BG-RMS="
            f"{row['background_rms_percent']:8.3f}%  "
            f"BG-max="
            f"{row['background_max_abs_percent']:8.3f}%"
        )

    print(
        "\n"
        + "=" * 88
    )

    print(
        "CONTAMINATION RELATIVE TO 0 m — raw-node metrics"
    )

    print(
        "=" * 88
    )

    for row in contamination_metrics:
        print(
            f"  {row['case']:6s} "
            f"{row['method']:14s} "
            f"target-change="
            f"{row['target_mean_change_pp']:8.4f} pp  "
            f"BG-RMS="
            f"{row['background_rms_contamination_pp']:8.4f} pp  "
            f"Global-RMS="
            f"{row['global_rms_contamination_pp']:8.4f} pp  "
            f"Global-max="
            f"{row['global_max_abs_contamination_pp']:8.4f} pp"
        )

    print(
        "\nSaved absolute-recovery outputs:"
    )

    for path in absolute_outputs:
        print(
            path
        )

    print(
        "\nSaved contamination-vs-0m outputs:"
    )

    for path in contamination_outputs:
        print(
            path
        )

    print(
        "\nSaved contamination trends:"
    )

    for path in trend_outputs:
        print(
            path
        )

    print(
        "\nSaved metrics:"
    )

    print(
        absolute_csv
    )

    print(
        contamination_csv
    )


if __name__ == "__main__":
    main()
