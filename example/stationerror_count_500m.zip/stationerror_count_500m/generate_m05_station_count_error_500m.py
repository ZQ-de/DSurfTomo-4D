#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Nested station-count coordinate-recording-error experiment for the -5% case.

Default design
--------------
- clean synthetic T1 travel times:
    change_m05pct/indT1/residualFirst.dat, column 3
- clean synthetic T2 travel times:
    change_m05pct/indT2/residualFirst.dat, column 3
- T1 = baseline truth
- T2 = baseline + -5% anomaly truth
- full path set retained; no path screening
- fixed coordinate error magnitude = 500 m
- erroneous station counts = 2, 4, 6, 8
- nested station sets: S2 ⊂ S4 ⊂ S6 ⊂ S8
- the same wrong coordinate for each station is used in T1 and T2
- all subsequent inversions MUST use synthetic = 0

Station selection
-----------------
1) Station #1: station inside the target box nearest the target center.
2) Station #2: nearby station outside the target box.
   These reproduce the previous two-station selection logic.
3) Stations #3-#8: greedy selection balancing spatial spread (70%) and
   observation-path degree (30%), producing a deterministic nested order.

Error directions
----------------
- Stations #1 and #2 keep 90 deg (east). The station order and error azimuths
  are required to match the completed 200 m station-count experiment exactly.
- Stations #3 onward receive reproducible random azimuths from a fixed seed.
- Every selected station keeps the same azimuth in T1 and T2 and in all nested
  cases in which it appears.

Output
------
/Users/zhaoqian/Desktop/stationerror/stationerror_count_500m/
    error2/
    error4/
    error6/
    error8/
    metadata_station_count_error/

Each errorN directory receives:
    surfdata_ind_T1.dat
    surfdata_ind_T2.dat
    surfdata_common_T1.dat
    surfdata_common_T2.dat
    surfdata_ref.dat
    surfdata_cur.dat
    station_coordinate_errors.csv
    README_stationerror_count.txt

Run
---
cd /Users/zhaoqian/Desktop/stationerror
python3 generate_m05_station_count_error_500m.py --overwrite
"""

from __future__ import annotations

from argparse import ArgumentParser
from dataclasses import dataclass
from pathlib import Path
import csv
import math
import shutil
from typing import Iterable

import numpy as np


DEFAULT_ROOT = Path("/Users/zhaoqian/Desktop/stationerror")
T1_SURF = "surfdata_T1.dat"
T2_SURF = "surfdata_T2.dat"
T1_RES = "change_m05pct/indT1/residualFirst.dat"
T2_RES = "change_m05pct/indT2/residualFirst.dat"
DEFAULT_OUT_PARENT = "stationerror_count_500m"
DEFAULT_SHIFT_M = 500.0
DEFAULT_COUNTS = (2, 4, 6, 8)
FIRST_TWO_AZIMUTH_DEG = 90.0
DEFAULT_SEED = 20260817

# Cross-check against the already completed 200 m experiment so that the
# 500 m stress test changes ONLY the coordinate-error magnitude.
REFERENCE_200M_DESIGN = (
    "stationerror_count_200m/metadata_station_count_error/"
    "selected_station_order.csv"
)
REFERENCE_200M_SUMMARY = (
    "stationerror_count_200m/metadata_station_count_error/"
    "station_count_error_summary.csv"
)
EARTH_RADIUS_M = 6371008.8
COORD_DECIMALS = 6

TARGET_LON_MIN = 121.460505
TARGET_LON_MAX = 121.511495
TARGET_LAT_MIN = 25.057500
TARGET_LAT_MAX = 25.102500

SPREAD_WEIGHT = 0.70
DEGREE_WEIGHT = 0.30

METHOD_DIRS = {
    "indT1": ("indT1", "ind_T1", "ind/indT1", "ind/T1"),
    "indT2": ("indT2", "ind_T2", "ind/indT2", "ind/T2"),
    "pdsT1": (
        "commonPDS_T1", "common_PDS_T1", "common-PDS/pdsT1",
        "common-PDS/common-PDST1", "common-PDS/indT1", "common-PDS/T1",
    ),
    "pdsT2": (
        "commonPDS_T2", "common_PDS_T2", "common-PDS/pdsT2",
        "common-PDS/common-PDST2", "common-PDS/indT2", "common-PDS/T2",
    ),
    "fourD": ("4D", "DSurfTomo4D", "fourD"),
}


def skey(lat: float, lon: float) -> tuple[float, float]:
    return round(float(lat), COORD_DECIMALS), round(float(lon), COORD_DECIMALS)


def pkey(src_lat, src_lon, period, wave_type, vel_type, rec_lat, rec_lon):
    return (
        round(float(src_lat), COORD_DECIMALS),
        round(float(src_lon), COORD_DECIMALS),
        int(period), int(wave_type), int(vel_type),
        round(float(rec_lat), COORD_DECIMALS),
        round(float(rec_lon), COORD_DECIMALS),
    )


@dataclass
class Record:
    rec_lat: float
    rec_lon: float
    rec_key: tuple[float, float]
    velocity: float
    key: tuple


@dataclass
class Block:
    src_lat: float
    src_lon: float
    src_key: tuple[float, float]
    period: int
    wave_type: int
    vel_type: int
    records: list[Record]


@dataclass
class SurfData:
    path: Path
    preamble: list[str]
    blocks: list[Block]

    @property
    def n_records(self):
        return sum(len(b.records) for b in self.blocks)


def read_surfdata(path: Path) -> SurfData:
    if not path.is_file():
        raise FileNotFoundError(path)

    preamble, blocks = [], []
    current = None
    seen_header = False
    seen_keys = set()

    for lineno, raw in enumerate(
        path.read_text(encoding="utf-8", errors="ignore").splitlines(), 1
    ):
        s = raw.strip()
        if not s:
            continue
        if s.lower().startswith("c"):
            if not seen_header:
                preamble.append(raw)
            continue
        if s.startswith("#"):
            q = s.split()
            if len(q) < 6:
                raise RuntimeError(f"Bad header at {path}:{lineno}: {raw}")
            lat, lon = float(q[1]), float(q[2])
            current = Block(
                src_lat=lat, src_lon=lon, src_key=skey(lat, lon),
                period=int(q[3]), wave_type=int(q[4]), vel_type=int(q[5]),
                records=[],
            )
            blocks.append(current)
            seen_header = True
            continue

        q = s.split()
        if len(q) < 3:
            continue
        if current is None:
            raise RuntimeError(f"Data before header at {path}:{lineno}")

        lat, lon, vel = float(q[0]), float(q[1]), float(q[2])
        key = pkey(
            current.src_lat, current.src_lon,
            current.period, current.wave_type, current.vel_type,
            lat, lon,
        )
        if key in seen_keys:
            raise RuntimeError(f"Duplicate path key in {path}: {key}")
        seen_keys.add(key)
        current.records.append(Record(lat, lon, skey(lat, lon), vel, key))

    data = SurfData(path, preamble, blocks)
    if data.n_records == 0:
        raise RuntimeError(f"No observations in {path}")
    return data


def ordered_records(data: SurfData):
    for block in data.blocks:
        for record in block.records:
            yield block, record


def ordered_keys(data: SurfData):
    return [r.key for _, r in ordered_records(data)]


def collect_stations(data: SurfData):
    stations = set()
    for block, record in ordered_records(data):
        stations.add(block.src_key)
        stations.add(record.rec_key)
    return sorted(stations)


def read_residual(path: Path) -> np.ndarray:
    if not path.is_file():
        raise FileNotFoundError(path)
    rows = []
    for raw in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        s = raw.strip()
        if not s or s.startswith("#") or s.lower().startswith("c"):
            continue
        try:
            vals = [float(x) for x in s.replace(",", " ").split()]
        except ValueError:
            continue
        if len(vals) >= 3:
            rows.append(vals)
    if not rows:
        raise RuntimeError(f"No numeric rows in {path}")
    return np.asarray(rows, dtype=float)


def gc_distance_m(lat1, lon1, lat2, lon2):
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp/2)**2 + math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
    a = max(0.0, min(1.0, a))
    return 2.0 * EARTH_RADIUS_M * math.asin(math.sqrt(a))


def destination(lat, lon, dist_m, azimuth_deg):
    if abs(dist_m) < 1e-15:
        return float(lat), float(lon)
    p1 = math.radians(lat)
    l1 = math.radians(lon)
    th = math.radians(azimuth_deg)
    d = dist_m / EARTH_RADIUS_M
    p2 = math.asin(
        math.sin(p1)*math.cos(d) + math.cos(p1)*math.sin(d)*math.cos(th)
    )
    l2 = l1 + math.atan2(
        math.sin(th)*math.sin(d)*math.cos(p1),
        math.cos(d) - math.sin(p1)*math.sin(p2),
    )
    return math.degrees(p2), math.degrees(l2)


def inside_target(station):
    lat, lon = station
    return (
        TARGET_LAT_MIN <= lat <= TARGET_LAT_MAX
        and TARGET_LON_MIN <= lon <= TARGET_LON_MAX
    )


def target_center():
    return (
        0.5*(TARGET_LAT_MIN + TARGET_LAT_MAX),
        0.5*(TARGET_LON_MIN + TARGET_LON_MAX),
    )


def target_center_distance(station):
    latc, lonc = target_center()
    return gc_distance_m(station[0], station[1], latc, lonc)


def array_azimuth_from_target(station):
    latc, lonc = target_center()
    dy = (station[0] - latc) * 111320.0
    dx = (station[1] - lonc) * 111320.0 * math.cos(math.radians(latc))
    az = math.degrees(math.atan2(dx, dy))
    return az + 360.0 if az < 0 else az


def station_degree(data: SurfData, station):
    n = 0
    for block, record in ordered_records(data):
        if block.src_key == station or record.rec_key == station:
            n += 1
    return n


def choose_first_two(data: SurfData, stations):
    inside = [s for s in stations if inside_target(s)]
    if inside:
        sta_in = min(
            inside,
            key=lambda s: (target_center_distance(s), -station_degree(data, s)),
        )
        note = "physically inside target box"
    else:
        sta_in = min(
            stations,
            key=lambda s: (target_center_distance(s), -station_degree(data, s)),
        )
        note = "NO station inside target box; nearest station used"

    outside = [s for s in stations if s != sta_in and not inside_target(s)]
    if not outside:
        raise RuntimeError("No outside-target station available")
    sta_out = min(
        outside,
        key=lambda s: (target_center_distance(s), -station_degree(data, s)),
    )
    return sta_in, sta_out, note


def choose_nested_station_order(data: SurfData, stations, n_total):
    sta_in, sta_out, note = choose_first_two(data, stations)
    selected = [sta_in, sta_out]
    selection_score = {sta_in: math.nan, sta_out: math.nan}

    degrees = {s: station_degree(data, s) for s in stations}
    max_degree = max(degrees.values())

    diameter = 0.0
    for i, a in enumerate(stations):
        for b in stations[i+1:]:
            diameter = max(diameter, gc_distance_m(a[0], a[1], b[0], b[1]))
    if diameter <= 0:
        raise RuntimeError("Station array diameter is zero")

    while len(selected) < n_total:
        best = None
        best_tuple = None
        best_score = None
        for candidate in stations:
            if candidate in selected:
                continue
            min_dist = min(
                gc_distance_m(candidate[0], candidate[1], s[0], s[1])
                for s in selected
            )
            spread_norm = min_dist / diameter
            degree_norm = degrees[candidate] / max_degree
            score = SPREAD_WEIGHT*spread_norm + DEGREE_WEIGHT*degree_norm
            tie = (score, degrees[candidate], min_dist, -candidate[0], -candidate[1])
            if best is None or tie > best_tuple:
                best = candidate
                best_tuple = tie
                best_score = score
        if best is None:
            raise RuntimeError("Failed to select next station")
        selected.append(best)
        selection_score[best] = best_score

    return selected, selection_score, note, degrees



def verify_against_200m_design(
    root: Path,
    selected,
    azimuths,
    counts,
):
    """
    Require the 500 m experiment to use exactly the same station ranks and
    coordinate-error azimuths as the completed 200 m experiment.

    This makes 200 m -> 500 m a clean one-variable stress test.
    """
    design_csv = root / REFERENCE_200M_DESIGN
    summary_csv = root / REFERENCE_200M_SUMMARY

    if not design_csv.is_file():
        raise FileNotFoundError(
            "Cannot find the 200 m reference design required for strict "
            f"cross-checking: {design_csv}"
        )

    with design_csv.open(
        "r",
        newline="",
        encoding="utf-8-sig",
    ) as f:
        rows = list(csv.DictReader(f))

    if len(rows) < max(counts):
        raise RuntimeError(
            f"200 m reference design has only {len(rows)} stations, "
            f"but the 500 m test needs {max(counts)}."
        )

    for rank, station in enumerate(selected, 1):
        ref = rows[rank - 1]

        ref_rank = int(ref["selection_rank"])
        ref_lat = float(ref["lat"])
        ref_lon = float(ref["lon"])
        ref_az = float(ref["coordinate_error_azimuth_deg"])

        if ref_rank != rank:
            raise RuntimeError(
                f"200 m reference rank mismatch at row {rank}: "
                f"selection_rank={ref_rank}"
            )

        if abs(station[0] - ref_lat) > 5e-7 or abs(station[1] - ref_lon) > 5e-7:
            raise RuntimeError(
                "500 m station selection does not match the 200 m experiment "
                f"at rank {rank}: current={station}, "
                f"reference=({ref_lat},{ref_lon})"
            )

        if abs(float(azimuths[station]) - ref_az) > 1e-9:
            raise RuntimeError(
                "500 m error azimuth does not match the 200 m experiment "
                f"at rank {rank}: current={azimuths[station]}, "
                f"reference={ref_az}"
            )

    print("\n===== 200 m -> 500 m design cross-check =====")
    print(
        f"PASS: station ranks 1-{len(selected)} and all error azimuths "
        "match the 200 m experiment exactly."
    )

    # Optional affected-path-count cross-check from the 200 m summary.
    reference_affected = {}

    if summary_csv.is_file():
        with summary_csv.open(
            "r",
            newline="",
            encoding="utf-8-sig",
        ) as f:
            for row in csv.DictReader(f):
                try:
                    nerr = int(row["n_station_error"])
                    npaths = int(row["n_paths_affected"])
                except (KeyError, ValueError):
                    continue
                reference_affected[nerr] = npaths

    return reference_affected

def assign_error_azimuths(selected, seed):
    azimuths = {
        selected[0]: FIRST_TWO_AZIMUTH_DEG,
        selected[1]: FIRST_TWO_AZIMUTH_DEG,
    }
    rng = np.random.default_rng(seed)
    for station in selected[2:]:
        azimuths[station] = float(rng.uniform(0.0, 360.0))
    return azimuths


def affected_path_keys(data: SurfData, erroneous_set):
    return {
        record.key
        for block, record in ordered_records(data)
        if block.src_key in erroneous_set or record.rec_key in erroneous_set
    }


def both_shifted_path_keys(data: SurfData, erroneous_set):
    return {
        record.key
        for block, record in ordered_records(data)
        if block.src_key in erroneous_set and record.rec_key in erroneous_set
    }


def write_epoch(template: SurfData, residual: np.ndarray, shift_map, output: Path):
    pairs = list(ordered_records(template))
    if len(pairs) != residual.shape[0]:
        raise RuntimeError(
            f"{template.path}: {len(pairs)} surfdata rows but "
            f"{residual.shape[0]} residual rows"
        )

    output.parent.mkdir(parents=True, exist_ok=True)
    affected = 0
    both_shifted = 0
    idx = 0
    errors_ms = []
    ratios = []

    with output.open("w", encoding="utf-8") as f:
        for line in template.preamble:
            f.write(line + "\n")

        for block in template.blocks:
            src_new = shift_map.get(block.src_key, (block.src_lat, block.src_lon))
            f.write(
                f"# {src_new[0]:.8f} {src_new[1]:.8f} "
                f"{block.period:d} {block.wave_type:d} {block.vel_type:d}\n"
            )

            for record in block.records:
                rr = residual[idx]
                idx += 1
                d_clean_program = rr[0]
                t_clean = rr[2]
                if d_clean_program <= 0 or t_clean <= 0:
                    raise RuntimeError(f"Bad residual row {idx}: {rr[:3]}")

                rec_new = shift_map.get(record.rec_key, (record.rec_lat, record.rec_lon))

                d_true_gc = gc_distance_m(
                    block.src_lat, block.src_lon, record.rec_lat, record.rec_lon
                )
                d_wrong_gc = gc_distance_m(
                    src_new[0], src_new[1], rec_new[0], rec_new[1]
                )
                if d_true_gc <= 0 or d_wrong_gc <= 0:
                    raise RuntimeError(f"Invalid path distance at record {idx}")

                ratio = d_wrong_gc / d_true_gc
                d_wrong_program = d_clean_program * ratio
                v_write = d_wrong_program / t_clean
                t_back = d_wrong_program / v_write

                errors_ms.append((t_back - t_clean) * 1000.0)
                ratios.append(ratio)

                src_shifted = block.src_key in shift_map
                rec_shifted = record.rec_key in shift_map
                if src_shifted or rec_shifted:
                    affected += 1
                if src_shifted and rec_shifted:
                    both_shifted += 1

                f.write(
                    f"{rec_new[0]:.8f} {rec_new[1]:.8f} {v_write:.15e}\n"
                )

    errors_ms = np.asarray(errors_ms, dtype=float)
    ratios = np.asarray(ratios, dtype=float)
    return {
        "n_records": len(pairs),
        "affected_records": affected,
        "both_endpoints_shifted_records": both_shifted,
        "affected_fraction_percent": affected / len(pairs) * 100.0,
        "tt_reconstruction_rms_ms": float(np.sqrt(np.mean(errors_ms**2))),
        "tt_reconstruction_maxabs_ms": float(np.max(np.abs(errors_ms))),
        "distance_ratio_min": float(np.min(ratios)),
        "distance_ratio_max": float(np.max(ratios)),
    }


def first_existing_method_dir(case_dir: Path, candidates: Iterable[str]):
    for rel in candidates:
        p = case_dir / rel
        if p.is_dir():
            return p
    return None


def copy_to_existing_method_dirs(case_dir: Path, generated, overwrite):
    copied = []
    for kind, src, filename in (
        ("indT1", generated["indT1"], "surfdata.dat"),
        ("indT2", generated["indT2"], "surfdata.dat"),
        ("pdsT1", generated["pdsT1"], "surfdata.dat"),
        ("pdsT2", generated["pdsT2"], "surfdata.dat"),
    ):
        d = first_existing_method_dir(case_dir, METHOD_DIRS[kind])
        if d is None:
            continue
        dst = d / filename
        if dst.exists() and not overwrite:
            raise FileExistsError(dst)
        shutil.copy2(src, dst)
        copied.append(str(dst))

    d = first_existing_method_dir(case_dir, METHOD_DIRS["fourD"])
    if d is not None:
        for src, filename in (
            (generated["ref"], "surfdata_ref.dat"),
            (generated["cur"], "surfdata_cur.dat"),
        ):
            dst = d / filename
            if dst.exists() and not overwrite:
                raise FileExistsError(dst)
            shutil.copy2(src, dst)
            copied.append(str(dst))
    return copied


def find_synthetic_one(case_dir: Path):
    warnings = []
    for p in case_dir.rglob("DSurfTomo.in"):
        for line in p.read_text(encoding="utf-8", errors="ignore").splitlines():
            if "synthetic" not in line.lower():
                continue
            left = line.split("c:", 1)[0].strip()
            if not left:
                continue
            try:
                value = int(round(float(left.split()[0])))
            except ValueError:
                continue
            if value != 0:
                warnings.append(f"{p}: synthetic={value}, MUST change to 0")
            break
    return warnings


def main():
    ap = ArgumentParser()
    ap.add_argument("--root", type=Path, default=DEFAULT_ROOT)
    ap.add_argument("--shift-m", type=float, default=DEFAULT_SHIFT_M)
    ap.add_argument("--counts", nargs="+", type=int, default=list(DEFAULT_COUNTS))
    ap.add_argument("--seed", type=int, default=DEFAULT_SEED)
    ap.add_argument("--out-parent", default=DEFAULT_OUT_PARENT)
    ap.add_argument("--overwrite", action="store_true")
    args = ap.parse_args()

    root = args.root.expanduser().resolve()
    if not root.is_dir():
        raise FileNotFoundError(root)
    if args.shift_m <= 0:
        raise ValueError("--shift-m must be > 0")

    counts = sorted(set(args.counts))
    if not counts or counts[0] < 2:
        raise ValueError("Counts must start at 2 or higher")

    t1 = read_surfdata(root / T1_SURF)
    t2 = read_surfdata(root / T2_SURF)
    r1 = read_residual(root / T1_RES)
    r2 = read_residual(root / T2_RES)

    if ordered_keys(t1) != ordered_keys(t2):
        raise RuntimeError("T1/T2 path keys/order are not identical")
    if t1.n_records != r1.shape[0] or t2.n_records != r2.shape[0]:
        raise RuntimeError(
            f"Row mismatch: surf={t1.n_records}/{t2.n_records}, "
            f"residual={r1.shape[0]}/{r2.shape[0]}"
        )

    dt = r2[:, 2] - r1[:, 2]
    print("===== Clean -5% synthetic audit =====")
    print(f"paths = {t1.n_records}")
    print(f"max |T2dist-T1dist| = {np.max(np.abs(r2[:,0]-r1[:,0])):.6e}")
    print(
        "clean Δt: mean={:.3f} ms, std={:.3f} ms, RMS={:.3f} ms".format(
            np.mean(dt)*1000.0,
            np.std(dt)*1000.0,
            np.sqrt(np.mean(dt**2))*1000.0,
        )
    )

    stations = sorted(set(collect_stations(t1)) & set(collect_stations(t2)))
    if max(counts) > len(stations):
        raise RuntimeError(
            f"Requested {max(counts)} erroneous stations but only "
            f"{len(stations)} exist"
        )

    selected, selection_scores, first_note, degrees = choose_nested_station_order(
        t1, stations, max(counts)
    )
    azimuths = assign_error_azimuths(selected, args.seed)

    reference_affected = verify_against_200m_design(
        root,
        selected,
        azimuths,
        counts,
    )

    print("\n===== Nested erroneous-station order =====")
    for rank, station in enumerate(selected, 1):
        role = (
            "target-side" if rank == 1
            else "near-target outside" if rank == 2
            else "spread-selected"
        )
        print(
            f"{rank:02d}. lat={station[0]:.6f}, lon={station[1]:.6f}, "
            f"role={role}, inside={inside_target(station)}, "
            f"degree={degrees[station]}, "
            f"array-az={array_azimuth_from_target(station):.1f}°, "
            f"error-az={azimuths[station]:.1f}°"
        )
    print(f"First-station note: {first_note}")
    print(f"Fixed coordinate error = {args.shift_m:g} m")
    print(f"Additional-station azimuth seed = {args.seed}")

    out_parent = root / args.out_parent
    out_parent.mkdir(parents=True, exist_ok=True)
    meta_dir = out_parent / "metadata_station_count_error"
    meta_dir.mkdir(parents=True, exist_ok=True)

    # Global selected-station design.
    selected_csv = meta_dir / "selected_station_order.csv"
    if selected_csv.exists() and not args.overwrite:
        raise FileExistsError(selected_csv)

    selected_rows = []
    for rank, station in enumerate(selected, 1):
        selected_rows.append({
            "selection_rank": rank,
            "role": (
                "target_side" if rank == 1
                else "near_target_outside" if rank == 2
                else "spread_selected"
            ),
            "lat": station[0],
            "lon": station[1],
            "inside_target": int(inside_target(station)),
            "path_degree": degrees[station],
            "distance_to_target_center_m": target_center_distance(station),
            "array_azimuth_from_target_deg": array_azimuth_from_target(station),
            "selection_score": selection_scores[station],
            "coordinate_error_m": args.shift_m,
            "coordinate_error_azimuth_deg": azimuths[station],
        })
    with selected_csv.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(selected_rows[0].keys()))
        w.writeheader()
        w.writerows(selected_rows)

    summary_rows = []
    previous_affected = set()

    for n_error in counts:
        case_name = f"error{n_error}"
        case_dir = out_parent / case_name
        case_dir.mkdir(parents=True, exist_ok=True)

        erroneous_list = selected[:n_error]
        erroneous_set = set(erroneous_list)
        affected_keys = affected_path_keys(t1, erroneous_set)
        both_keys = both_shifted_path_keys(t1, erroneous_set)

        if n_error in reference_affected:
            if len(affected_keys) != reference_affected[n_error]:
                raise RuntimeError(
                    f"{case_name}: affected-path count {len(affected_keys)} "
                    f"does not match the 200 m reference "
                    f"{reference_affected[n_error]}."
                )

        if not previous_affected.issubset(affected_keys):
            raise RuntimeError(f"{case_name}: affected paths are not nested")
        previous_affected = affected_keys

        shift_map = {
            station: destination(
                station[0], station[1], args.shift_m, azimuths[station]
            )
            for station in erroneous_list
        }

        generated = {
            "indT1": case_dir / "surfdata_ind_T1.dat",
            "indT2": case_dir / "surfdata_ind_T2.dat",
            "pdsT1": case_dir / "surfdata_common_T1.dat",
            "pdsT2": case_dir / "surfdata_common_T2.dat",
            "ref": case_dir / "surfdata_ref.dat",
            "cur": case_dir / "surfdata_cur.dat",
        }
        for p in generated.values():
            if p.exists() and not args.overwrite:
                raise FileExistsError(p)

        s1 = write_epoch(t1, r1, shift_map, generated["indT1"])
        s2 = write_epoch(t2, r2, shift_map, generated["indT2"])

        # No screening: all methods receive the same complete observations.
        shutil.copy2(generated["indT1"], generated["pdsT1"])
        shutil.copy2(generated["indT2"], generated["pdsT2"])
        shutil.copy2(generated["indT1"], generated["ref"])
        shutil.copy2(generated["indT2"], generated["cur"])

        coord_csv = case_dir / "station_coordinate_errors.csv"
        if coord_csv.exists() and not args.overwrite:
            raise FileExistsError(coord_csv)
        coord_rows = []
        for rank, station in enumerate(erroneous_list, 1):
            wrong = shift_map[station]
            coord_rows.append({
                "selection_rank": rank,
                "role": (
                    "target_side" if rank == 1
                    else "near_target_outside" if rank == 2
                    else "spread_selected"
                ),
                "true_lat": station[0],
                "true_lon": station[1],
                "recorded_lat": wrong[0],
                "recorded_lon": wrong[1],
                "requested_shift_m": args.shift_m,
                "realized_shift_m": gc_distance_m(
                    station[0], station[1], wrong[0], wrong[1]
                ),
                "error_azimuth_deg": azimuths[station],
                "inside_target": int(inside_target(station)),
                "path_degree": degrees[station],
            })
        with coord_csv.open("w", newline="", encoding="utf-8-sig") as f:
            w = csv.DictWriter(f, fieldnames=list(coord_rows[0].keys()))
            w.writeheader()
            w.writerows(coord_rows)

        copied = copy_to_existing_method_dirs(case_dir, generated, args.overwrite)
        warnings = find_synthetic_one(case_dir)

        readme = case_dir / "README_stationerror_count.txt"
        readme.write_text(
            "\n".join([
                f"Nested station-count coordinate-recording-error case: {case_name}",
                "",
                "Truth:",
                "  T1 = clean baseline synthetic travel times",
                "  T2 = clean baseline + -5% anomaly synthetic travel times",
                "  clean travel times come from residualFirst.dat column 3",
                "",
                "Controlled error:",
                f"  erroneous stations = {n_error}/{len(stations)}",
                f"  fixed shift magnitude = {args.shift_m:g} m",
                "  each selected station uses the same wrong coordinate in T1 and T2",
                f"  first two error azimuths = {FIRST_TWO_AZIMUTH_DEG:g} deg",
                f"  additional-station azimuth seed = {args.seed}",
                "",
                "Observation system:",
                f"  full paths = {t1.n_records}",
                f"  affected paths = {len(affected_keys)}",
                f"  affected fraction = {len(affected_keys)/t1.n_records*100.0:.6f}%",
                f"  paths with both endpoints erroneous = {len(both_keys)}",
                "  no paths are deleted",
                "",
                "MANDATORY: synthetic = 0",
                "",
                f"T1 audit: {s1}",
                f"T2 audit: {s2}",
                f"Auto-copied: {copied}",
                f"Warnings: {warnings}",
            ]) + "\n",
            encoding="utf-8",
        )

        print("\n" + "="*76)
        print(f"case = {case_name}")
        print(
            f"erroneous stations = {n_error}/{len(stations)} "
            f"({n_error/len(stations)*100.0:.2f}%)"
        )
        print(f"full paths = {t1.n_records}")
        print(
            f"affected paths = {len(affected_keys)}/{t1.n_records} "
            f"({len(affected_keys)/t1.n_records*100.0:.2f}%)"
        )
        print(f"paths with both endpoints erroneous = {len(both_keys)}")
        print(
            "travel-time reconstruction maxabs error T1/T2 = "
            f"{s1['tt_reconstruction_maxabs_ms']:.3e}/"
            f"{s2['tt_reconstruction_maxabs_ms']:.3e} ms"
        )
        for rank, station in enumerate(erroneous_list, 1):
            wrong = shift_map[station]
            print(
                f"  {rank:02d}. ({station[0]:.6f},{station[1]:.6f}) -> "
                f"({wrong[0]:.8f},{wrong[1]:.8f}), "
                f"azimuth={azimuths[station]:.1f}°"
            )
        if warnings:
            print("WARNING:")
            for warning in warnings:
                print("  " + warning)

        summary_rows.append({
            "case": case_name,
            "shift_m": args.shift_m,
            "n_station_total": len(stations),
            "n_station_error": n_error,
            "station_error_fraction_percent": n_error/len(stations)*100.0,
            "n_paths_total": t1.n_records,
            "n_paths_affected": len(affected_keys),
            "path_affected_fraction_percent": len(affected_keys)/t1.n_records*100.0,
            "n_paths_both_endpoints_error": len(both_keys),
            "T1_tt_reconstruction_maxabs_ms": s1["tt_reconstruction_maxabs_ms"],
            "T2_tt_reconstruction_maxabs_ms": s2["tt_reconstruction_maxabs_ms"],
            "synthetic_flag_warnings": " | ".join(warnings),
            "erroneous_stations": "; ".join(
                f"{rank}:{station[0]:.6f},{station[1]:.6f},az={azimuths[station]:.3f}"
                for rank, station in enumerate(erroneous_list, 1)
            ),
        })

    summary_csv = meta_dir / "station_count_error_summary.csv"
    if summary_csv.exists() and not args.overwrite:
        raise FileExistsError(summary_csv)
    with summary_csv.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(summary_rows[0].keys()))
        w.writeheader()
        w.writerows(summary_rows)

    design = meta_dir / "README_design.txt"
    if design.exists() and not args.overwrite:
        raise FileExistsError(design)
    design.write_text(
        "\n".join([
            "Nested station-count coordinate-recording-error experiment",
            "",
            f"Clean paths: {t1.n_records}",
            f"Clean -5% differential-traveltime RMS: {np.sqrt(np.mean(dt**2))*1000.0:.3f} ms",
            f"Fixed coordinate error: {args.shift_m:g} m",
            "Erroneous station counts: " + ", ".join(str(x) for x in counts),
            "Nested design: S2 subset S4 subset S6 subset S8",
            f"Total stations: {len(stations)}",
            f"First two station error azimuths: {FIRST_TWO_AZIMUTH_DEG:g} deg",
            f"Additional station azimuth seed: {args.seed}",
            f"Additional station selection: {SPREAD_WEIGHT:.2f} spread + {DEGREE_WEIGHT:.2f} path degree",
            "",
            "All cases retain the full path set.",
            "The same erroneous coordinates are used in T1 and T2.",
            "All inversions MUST use synthetic = 0.",
            "",
            "Independent and common-PDS are data-equivalent here because the two epochs",
            "contain the same complete observation set. If inversion settings are identical,",
            "one T1 absolute inversion and one T2 absolute inversion are sufficient.",
        ]) + "\n",
        encoding="utf-8",
    )

    print("\n" + "="*76)
    print("Generation completed.")
    print(f"Output root: {out_parent}")
    print(f"Selected-station design: {selected_csv}")
    print(f"Summary: {summary_csv}")
    print(f"Design README: {design}")
    print("\nCRITICAL:")
    print("  - No paths were deleted.")
    print("  - T1/T2 use the same erroneous coordinates.")
    print("  - Clean synthetic travel times were preserved.")
    print("  - All inversion runs must use synthetic = 0.")
    print("  - Station identities and error azimuths match the 200 m experiment.")
    print("  - Therefore 200 m -> 500 m changes only coordinate-error magnitude.")
    print("  - the station order, affected-path counts, and error azimuths must match the 200 m experiment exactly.")


if __name__ == "__main__":
    main()
