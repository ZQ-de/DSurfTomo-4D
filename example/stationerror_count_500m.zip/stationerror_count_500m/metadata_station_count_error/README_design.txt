Nested station-count coordinate-recording-error experiment

Clean paths: 2092
Clean -5% differential-traveltime RMS: 61.268 ms
Fixed coordinate error: 500 m
Erroneous station counts: 2, 4, 6, 8
Nested design: S2 subset S4 subset S6 subset S8
Total stations: 20
First two station error azimuths: 90 deg
Additional station azimuth seed: 20260817
Additional station selection: 0.70 spread + 0.30 path degree

All cases retain the full path set.
The same erroneous coordinates are used in T1 and T2.
All inversions MUST use synthetic = 0.

Independent and common-PDS are data-equivalent here because the two epochs
contain the same complete observation set. If inversion settings are identical,
one T1 absolute inversion and one T2 absolute inversion are sufficient.
